def list_conversion(vals):
    return list(map(int, vals))

# print(list_conversion(["1", "2", "3"]))

def if_else_stuff():
    a = 10
    b = 5
    c = 5
    if True:
        print("This will print")
    else:
        print("This will not")
    
    if a == b:
        print("A == B")
    elif a == c:
        print("A == C")
    elif b == c or b == 4:
        print("B == C or B == 4")

def echo():
    a = input("Just type something: ")
    print("This is what you typed: " + a)

# echo()

def print_strnum(num, string):
    print(str(num) + " " + string)

# print_strnum(133, 't')

def print_strnum2(num, string="hello"):
    print(str(num) + " " + string)

# print_strnum2(50)

def complex_math(num1=1, num2=5, num3=6):
    return num1 * num2 ** num3

print(complex_math())

print(complex_math(3, 4))

print(complex_math(num3=2))

def print_n(n):
    for i in range(n):
        print(i)

# print_n(10)

def print_n2(n):
    for i in range(1, n, 2):
        print(i)

# print_n2(20)

def get_numbers():
    vals = []
    val = int(input("Enter a number: "))
    while val != 0:
        vals.append(val)
        val = int(input("Enter another number: "))
    return vals

# print(get_numbers())

class Sample():
    y = 0.5

    def __init__(self):
        self.x = 1

    def set_x(self, x):
        self.x = x
    
    def print_xy(self):
        print(self.x + " " + self.y)

# s = Sample()

# s.set_x(10)
# s.print_xy()

def print_file(name):
    f = open(name, 'r')
    for line in f.readlines():
        print(line)
    f.close()

# print_file("test.txt")

def print_file2(name):
    with open(name, 'r') as f:
        for line in f.readlines():
            print(line)

# print_file2("test.txt")

def record_input(n):
    data = []
    for i in range(n):
        line = input("Enter line " + str(i) + ": ")
        data.append(line)
    with open("recorded.txt", "w+") as f:
        for line in data:
            f.write(line + "\n")

# record_input(3)

def record_input2(n):
    data = []
    for i in range(n):
        line = input("Enter line " + str(i) + ": ")
        data.append(line)
    with open("recorded.txt", "a+") as f:
        for line in data:
            f.write(line + "\n")

# record_input(3)
# record_input(2)

def rect_example():
    import rectangle

    rect = rectangle.Rectangle(10, 10, 20, 20)
    rect2 = rectangle.create_random()
    rect.print_details()
    rect2.print_details()

# rect_example()

def rect_example2():
    from rectangle import Rectangle

    rect = Rectangle(10, 20, 30, 40)
    rect.print_details()

# rect_example2()

