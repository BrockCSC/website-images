import matplotlib.pyplot as plt

with open('data.csv', 'r') as f:
    months = f.readline().strip().split(',')[1:]
    highs = f.readline().strip().split(',')[1:]
    highs = list(map(int, highs))
    lows = f.readline().strip().split(',')[1:]
    lows = list(map(int, lows))

highs_line, = plt.plot(months, highs, 'b', label="Highs")
lows_line, = plt.plot(months, lows, 'g', label="Lows")
plt.legend(handles=[highs_line, lows_line])
plt.title("Average high and low temperature for St. Catharines, 2018")
plt.xlabel("Month")
plt.ylabel("Temperature in Degrees Celsius")
plt.show()

