import sys, pygame
pygame
size = width, height = 640, 480
speed = [2,2]
black = 0,0,0
dirx = 1
diry = 1

screen = pygame.display.set_mode(size)

ball = pygame.image.load("intro_ball.gif")
ballrect = ball.get_rect()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        # elif event.type == pygame.KEYDOWN:
        #     if event.key == pygame.K_UP:
        #         speed[1] += 1
        #         speed[0] += 1
        #     elif event.key == pygame.K_DOWN:
        #         speed[0] -= 1
        #         speed[1] -= 1

    ballrect = ballrect.move([speed[0]*dirx, speed[1]*diry])
    if ballrect.left < 0 or ballrect.right > width:
        dirx = -dirx
    if ballrect.top < 0 or ballrect.bottom > height:
        diry = -diry

    screen.fill(black)
    screen.blit(ball, ballrect)
    pygame.display.flip()