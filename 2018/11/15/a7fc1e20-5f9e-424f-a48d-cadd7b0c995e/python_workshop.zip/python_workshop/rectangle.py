from random import Random

class Rectangle():

    def __init__(self, x, y, length, width):
        self.x = x
        self.y = y
        self.length = length
        self.width = width

    def get_area(self):
        return self.length * self.width

    def contains(self, x, y):
        if x > self.x and x < self.x+self.length and y > self.y and y < self.y+self.width:
            return True
        else:
            return False

    def print_details(self):
        print("X: {0}, Y: {1}, Length: {2}, Width: {3}".format(self.x, self.y, self.length, self.width))

def create_square(x, y, length):
    return Rectangle(x, y, length, length)

def create_random():
    r = Random()
    return Rectangle(r.randint(1, 20), r.randint(1, 20), r.randint(1, 20), r.randint(1, 20))
