import requests

r = requests.get('https://api.github.com/users/BrockCSC')
print(r.json())

